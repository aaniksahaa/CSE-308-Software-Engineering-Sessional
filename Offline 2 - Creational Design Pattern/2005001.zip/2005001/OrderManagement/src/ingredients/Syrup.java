package ingredients;

public class Syrup {
    private Type type;

    public Syrup(Type type){
        this.type = type;
    }

    public Type getType() {
        return type;
    }

    public void setType(Type type) {
        this.type = type;
    }
}
