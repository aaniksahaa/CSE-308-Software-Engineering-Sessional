import entities.ShakeVariant;
import order.OrderManagement;


public class Main {
    public static void main(String[] args) {
        OrderManagement orderManagement = new OrderManagement();
        orderManagement.run();
    }
}