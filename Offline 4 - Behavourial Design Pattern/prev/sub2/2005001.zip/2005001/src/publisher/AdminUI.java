package publisher;

public class AdminUI {
    public static void main(String[] args) throws Exception{
        StockAdministrator admin = new StockAdministrator();
        admin.run();
    }
}
