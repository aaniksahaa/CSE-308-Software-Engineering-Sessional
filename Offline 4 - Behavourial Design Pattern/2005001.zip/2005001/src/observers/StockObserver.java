package observers;

public interface StockObserver {
    public void update(String message);
}
