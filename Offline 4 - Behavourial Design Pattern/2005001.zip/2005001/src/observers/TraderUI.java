package observers;

public class TraderUI {
    public static void main(String[] args) {
        StockTrader trader = new StockTrader();
        trader.run();
    }
}
