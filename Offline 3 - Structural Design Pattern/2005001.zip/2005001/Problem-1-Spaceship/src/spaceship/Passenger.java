package spaceship;

public interface Passenger {
    void login();
    void repair();
    void work();
    void logout();
}
