package commandShell;

public class ErrorHandler {
    static void handleInvalidArgumentCount(){
        System.out.println("Sorry! Invalid number of arguments for the given command.");
    }
}
