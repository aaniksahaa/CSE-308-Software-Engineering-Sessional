package finance;

public class Constants {
    public static final String SAVINGS = "Savings";
    public static final String STUDENT = "Student";
    public static final String FIXED_DEPOSIT = "Fixed-Deposit";
    public static final int NOT_APPLICABLE = -1;
    // Add more constants as needed
}

