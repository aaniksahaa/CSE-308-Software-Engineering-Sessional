package employee;

public class ManagingDirector extends Employee{
    public ManagingDirector(String name){
        super(name);
    }
}
