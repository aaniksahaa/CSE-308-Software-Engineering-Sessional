package adapter.parser;
import java.io.File;

public interface Parser {
    int calculateSum(File fr);
}
