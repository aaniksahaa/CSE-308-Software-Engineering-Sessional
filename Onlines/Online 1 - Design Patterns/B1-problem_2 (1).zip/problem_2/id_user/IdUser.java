package id_user;

public interface IdUser {
    void doWork();
}
