package id_generator;

public interface IdGenerator {
    int generate();
}
